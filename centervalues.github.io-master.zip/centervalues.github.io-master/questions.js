questions = [
    {
        "question": "Giving lots of power to megacorporations is not much different from giving same ammount of power to the goverment.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
        {
        "question": "Nazis and communists are basically the same.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
            {
        "question": "Anarcho-(insert_random_ideology_name) is the same as any other type of anarchism.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
            {
        "question": "Totalitarian regimes = literally 1984, no matter the policies.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
            {
        "question": "Anti-fascist and social justice movements are as biggoted as those whom they oppose.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
            {
        "question": "Everyone far-right is a nazi.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
            {
        "question": "Everyone far-left is a stalinist.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
            {
        "question": "All libs are leftists.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
            {
        "question": "Theists and atheists are equally vocal and annoying.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
    {
        "question": "Current political status quo is okay, even if it needs minor improvements.",
        "effect": {
            "ther": 0,
            "belf": 10,
            "polc": 0,
            "cord": 0
        }
    },
            {
        "question": "Whoever wrote the previous question has a major case of dumb.",
        "effect": {
            "ther": 0,
            "belf": -10,
            "polc": 0,
            "cord": 0
        }
    },
                {
        "question": "Technological, cultural and societal progress go hand-in-hand with each other.",
        "effect": {
            "ther": 0,
            "belf": 10,
            "polc": 0,
            "cord": 0
        }
    },
                {
        "question": "The traditon/progress axis is stupid. Supporting science should not be equated to being pro-lgbt or pro-racial equality. The same goes the other way around.",
        "effect": {
            "ther": 0,
            "belf": -10,
            "polc": 0,
            "cord": 0
        }
    },
                {
        "question": "Extremists and/or a group I dislike deserve to fucking die. That's the only way to achieve peace.",
        "effect": {
            "ther": 0,
            "belf": -10,
            "polc": 0,
            "cord": 0
        }
    },
                {
        "question": "Authoritarian goverment allows the ones in control to commit serious crimes against people's rights, which is bad, but that issue shouldn't be resolved by the drastic measures of removing authority altogether.",
        "effect": {
            "ther": 0,
            "belf": 10,
            "polc": 0,
            "cord": 0
        }
    },
                {
        "question": "Saying that all races/cultures are the exact same is wrong, but so is thinking that racial/cultural background is the main factor in ones actions.",
        "effect": {
            "ther": 0,
            "belf": 10,
            "polc": 0,
            "cord": 0
        }
    },
                {
        "question": "The most drastic measure for political change is a demonstration/protest. Anything more extreme than that is just meaningless violence.",
        "effect": {
            "ther": 0,
            "belf": 10,
            "polc": 0,
            "cord": 0
        }
    },
    {
        "question": "I would only participate in a protest if I'm sure that things will not get violent.",
        "effect": {
            "ther": 0,
            "belf": 10,
            "polc": 0,
            "cord": 0
        }
    },
    {
        "question": "I would not participate in any kind of protest.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": -10,
            "cord": 0
        }
    },
               {
        "question": "Serious political media does not interest me.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": -10,
            "cord": 0
        }
    },
                   {
        "question": "I do not want to vote on any political candidate/party.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": -10,
            "cord": 0
        }
    },
                   {
        "question": "I know the name of the president, prime minister, chancellor and multiple other politicians of my country.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 10,
            "cord": 0
        }
    },
  {
        "question": "I have never learned history/Forgot most of it.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": -10,
            "cord": 0
        }
    },
 {
        "question": "My knowledge of politics mostly comes from internet memes and/or satirical media.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": -10,
            "cord": 0
        }
    },
 {
        "question": "I have debated about my political beliefs multiple times.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 10,
            "cord": 0
        }
    },
    {
        "question": "Whenever someone talks about something even slightly related to social issues, I tell them to quit being so political or at least think about telling them so.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": -10,
            "cord": 0
        }
    },
    {
        "question": "If I see a political show and/or news on TV, I change the channel.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": -10,
            "cord": 0
        }
    },
    {
        "question": "ONLY ONE of these is correct: Righ-Wingers generally provide more logical and constructive arguments | Left-Wingers are reasonable.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
    },
        {
        "question": "ONLY ONE of these is correct: The freer the markets, the freer the people | The freer the people, the freer the markets.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
    },
       {
        "question": "ONLY ONE of these is correct: White identarians are not racists | Furries are not gay.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
     },
            {
        "question": "ONLY ONE of these is correct: Communalism means robbery | Social darwinism means murder.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
     },
          {
        "question": "ONLY ONE of these is correct: Totalitarism is an unnecessary evil | Anarchy is unnecessary chaos.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
     },
        {
        "question": "ONLY ONE of these is correct: Most herbivore animals are opportunistic carnivores | Animal cruelty is an issue that needs to be dealt with.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
     },
      {
        "question": "ONLY ONE of these is correct: Police doesn't need guns to protect people | Citizens don't need guns to protect themselves.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
     },
      {
        "question": "ONLY ONE of these is correct: I love my country/nation | Most choices my country makes are very questionable.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
     },
      {
        "question": "ONLY ONE of these is correct: There is no morality without god | If god exists, he's either not omnipotent or not benevolent.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": -10
        }
     },
      {
        "question": "Whenever I see people arguing, I try to find compromise between both opinions instead of taking sides.",
        "effect": {
            "ther": 0,
            "belf": 10,
            "polc": 0,
            "cord": 10
        }
     },
      {
        "question": "The more axes a political test has, the better.",
        "effect": {
            "ther": 10,
            "belf": -10,
            "polc": 0,
            "cord": 0
        }
     },
      {
        "question": "All modern-day politicians are extremely close to each other in their political beliefs.",
        "effect": {
            "ther": -10,
            "belf": 0,
            "polc": -10,
            "cord": 0
        }
     },
      {
        "question": "Not choosing a lesser evil will give rise to a greater evil.",
        "effect": {
            "ther": 0,
            "belf": 0,
            "polc": 10,
            "cord": -10
        }
     },
];
