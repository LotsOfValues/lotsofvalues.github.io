# centervalues
A parody test that is not meant to be taken seriously.
