ideologies = [
    {
        "name": "Self-righteous Cowboy",
        "stats": {
            "ther": 0,
            "belf": 50,
            "polc": 50,
            "cord": 50
        }
    },
    {
        "name": "№ of people = № of ideologies",
        "stats": {
            "ther": 100,
            "belf": 50,
            "polc": 50,
            "cord": 50
        }
    },
    {
        "name": "Meta-Centrism",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 50,
            "cord": 50
        }
    },
        {
        "name": "Greguevarianist",
        "stats": {
            "ther": 50,
            "belf": 0,
            "polc": 50,
            "cord": 50
        }
    },
    {
        "name": "Bullied Kid",
        "stats": {
            "ther": 50,
            "belf": 100,
            "polc": 50,
            "cord": 50
        }
    },
    {
        "name": "Top Chef",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 0,
            "cord": 50
        }
    },
    {
        "name": "Modern-day Politician",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 100,
            "cord": 50
        }
    },
    {
        "name": "Universal Center",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 50,
            "cord": 100
        }
    },
    {
        "name": "Enlightened Centrist",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 50,
            "cord": 0
        }
    },
    {
        "name": "Just-me-thnostatist",
        "stats": {
            "ther": 0,
            "belf": 0,
            "polc": 50,
            "cord": 50
        }
    },
    {
        "name": "Sad Loner",
        "stats": {
            "ther": 0,
            "belf": 100,
            "polc": 50,
            "cord": 50
        }
    },
        {
        "name": "Ironic Anti-Centrism",
        "stats": {
            "ther": 100,
            "belf": 0,
            "polc": 50,
            "cord": 50
        }
    },
    {
        "name": "Liberal Centrism",
        "stats": {
            "ther": 100,
            "belf": 100,
            "polc": 50,
            "cord": 50
        }
    },
    {
        "name": "Unironic Anti-Centrism",
        "stats": {
            "ther": 100,
            "belf": 0,
            "polc": 50,
            "cord": 0
        }
    },
    {
        "name": "Extremist Spy",
        "stats": {
            "ther": 100,
            "belf": 0,
            "polc": 100,
            "cord": 0
        }
    },
    {
        "name": "True Centrist",
        "stats": {
            "ther": 25,
            "belf": 100,
            "polc": 75,
            "cord": 100
        }
    },
    {
        "name": "Boomer Centrist",
        "stats": {
            "ther": 0,
            "belf": 50,
            "polc": 0,
            "cord": 50
        }
    },
    {
        "name": "Weakling Centrist",
        "stats": {
            "ther": 100,
            "belf": 100,
            "polc": 0,
            "cord": 100
        }
    },
    {
        "name": "Based and Redpilled",
        "stats": {
            "ther": 0,
            "belf": 0,
            "polc": 100,
            "cord": 0
        }
    },
    {
        "name": "Hellgriller",
        "stats": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
    {
        "name": "Senatorialist",
        "stats": {
            "ther": 0,
            "belf": 0,
            "polc": 100,
            "cord": 100
        }
    },
    {
        "name": "Moralist",
        "stats": {
            "ther": 100,
            "belf": 100,
            "polc": 25,
            "cord": 50
        }
    },
    {
        "name": "Realist",
        "stats": {
            "ther": 100,
            "belf": 100,
            "polc": 100,
            "cord": 100
        }
    },
    {
        "name": "Inversive Realist",
        "stats": {
            "ther": 0,
            "belf": 50,
            "polc": 100,
            "cord": 100
        }
    },
    {
        "name": "Boring Realist",
        "stats": {
            "ther": 50,
            "belf": 100,
            "polc": 0,
            "cord": 100
        }
    },
    {
        "name": "Immoralist",
        "stats": {
            "ther": 50,
            "belf": 0,
            "polc": 50,
            "cord": 0
        }
    },
    {
        "name": "Occam Realist",
        "stats": {
            "ther": 25,
            "belf": 100,
            "polc": 50,
            "cord": 100
        }
    },
    {
        "name": "Orwellian Realist",
        "stats": {
            "ther": 0,
            "belf": 100,
            "polc": 100,
            "cord": 100
        }
    },
    {
        "name": "Fishhook theorist",
        "stats": {
            "ther": 25,
            "belf": 50,
            "polc": 50,
            "cord": 0
        }
    },
    {
        "name": "Centrist Anti-Centrist",
        "stats": {
            "ther": 100,
            "belf": 0,
            "polc": 75,
            "cord": 75
        }
    },
    {
        "name": "Moderate Anti-Centrist",
        "stats": {
            "ther": 100,
            "belf": 100,
            "polc": 100,
            "cord": 50
        }
    },
    {
        "name": "Fake Centrist",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 100,
            "cord": 0
        }
    },
    {
        "name": "Radical Centrist",
        "stats": {
            "ther": 75,
            "belf": 0,
            "polc": 100,
            "cord": 100
        }
    },
    {
        "name": "Anti-Extremist",
        "stats": {
            "ther": 0,
            "belf": 100,
            "polc": 50,
            "cord": 100
        }
    },
    {
        "name": "Apolitical",
        "stats": {
            "ther": 0,
            "belf": 50,
            "polc": 0,
            "cord": 75
        }
    },
    {
        "name": "Radical Apolitical",
        "stats": {
            "ther": 0,
            "belf": 0,
            "polc": 0,
            "cord": 100
        }
    },
    {
        "name": "Political Nihilist",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 0,
            "cord": 0
        }
    },
    {
        "name": "Centrist Sympathiser",
        "stats": {
            "ther": 100,
            "belf": 50,
            "polc": 100,
            "cord": 0
        }
    },
    {
        "name": "Singularity Centrism",
        "stats": {
            "ther": 100,
            "belf": 50,
            "polc": 50,
            "cord": 100
        }
    },
    {
        "name": "Extremism",
        "stats": {
            "ther": 100,
            "belf": 50,
            "polc": 50,
            "cord": 0
        }
    },
    {
        "name": "Anti-flairism",
        "stats": {
            "ther": 50,
            "belf": 0,
            "polc": 25,
            "cord": 50
        }
    },
    {
        "name": "Normie",
        "stats": {
            "ther": 50,
            "belf": 100,
            "polc": 0,
            "cord": 50
        }
    },
    {
        "name": "Radical Moderate",
        "stats": {
            "ther": 0,
            "belf": 25,
            "polc": 0,
            "cord": 75
        }
    },
    {
        "name": "Aroace Agender Apolitical Atheist",
        "stats": {
            "ther": 100,
            "belf": 25,
            "polc": 0,
            "cord": 25
        }
    },
    {
        "name": "Fence with windows",
        "stats": {
            "ther": 75,
            "belf": 50,
            "polc": 75,
            "cord": 25
        }
    },
    {
        "name": "Contradictionalism",
        "stats": {
            "ther": 100,
            "belf": 0,
            "polc": 0,
            "cord": 100
        }
    },
    {
        "name": "Populism",
        "stats": {
            "ther": 100,
            "belf": 25,
            "polc": 100,
            "cord": 50
        }
    },
    {
        "name": "Extremist Centrism",
        "stats": {
            "ther": 100,
            "belf": 0,
            "polc": 100,
            "cord": 100
        }
    },
    {
        "name": "Gravitational Centrism",
        "stats": {
            "ther": 50,
            "belf": 0,
            "polc": 0,
            "cord": 100
        }
    },
    {
        "name": "Politicophobe",
        "stats": {
            "ther": 25,
            "belf": 75,
            "polc": 0,
            "cord": 75
        }
    },
    {
        "name": "Status Quo Upholder",
        "stats": {
            "ther": 75,
            "belf": 75,
            "polc": 50,
            "cord": 50
        }
    },
    {
        "name": "Blind Follower",
        "stats": {
            "ther": 80,
            "belf": 100,
            "polc": 25,
            "cord": 40
        }
    },
    {
        "name": "Average Non-voter",
        "stats": {
            "ther": 20,
            "belf": 80,
            "polc": 20,
            "cord": 80
        }
    },
    {
        "name": "Thanosism",
        "stats": {
            "ther": 50,
            "belf": 0,
            "polc": 40,
            "cord": 20
        }
    },
    {
        "name": "Peacemaker",
        "stats": {
            "ther": 75,
            "belf": 100,
            "polc": 30,
            "cord": 80
        }
    },
    {
        "name": "Optimistic Centrism",
        "stats": {
            "ther": 75,
            "belf": 100,
            "polc": 0,
            "cord": 100
        }
    },
    {
        "name": "Political Doomer",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 25,
            "cord": 40
        }
    },
    {
        "name": "Uninformed Centrism",
        "stats": {
            "ther": 25,
            "belf": 50,
            "polc": 40,
            "cord": 80
        }
    },
    {
        "name": "UK Voter",
        "stats": {
            "ther": 60,
            "belf": 50,
            "polc": 70,
            "cord": 75
        }
    },
    {
        "name": "Inoffensive Centrist Democracy",
        "stats": {
            "ther": 75,
            "belf": 100,
            "polc": 50,
            "cord": 75
        }
    },
    {
        "name": "Someone with opinions",
        "stats": {
            "ther": 70,
            "belf": 35,
            "polc": 60,
            "cord": 75
        }
    },
    {
        "name": "Neocentrism",
        "stats": {
            "ther": 0,
            "belf": 100,
            "polc": 0,
            "cord": 0
        }
    },
    {
        "name": "Post-centrism",
        "stats": {
            "ther": 50,
            "belf": 0,
            "polc": 0,
            "cord": 0
        }
    },
    {
        "name": "Anti-politicism",
        "stats": {
            "ther": 0,
            "belf": 100,
            "polc": 0,
            "cord": 50
        }
    },
    {
        "name": "My name is Yoshikage Kira. I'm 33 years old. My house is in the northeast section of Morioh, where all the villas are, and I am not married. I work as an employee for the Kame Yu department stores, and I get home every day by 8 PM at the latest. I don't smoke, but I occasionally drink. I'm in bed by 11 PM, and make sure I get eight hours of sleep, no matter what. After having a glass of warm milk and doing about twenty minutes of stretches before going to bed, I usually have no problems sleeping until morning. Just like a baby, I wake up without any fatigue or stress in the morning. I was told there were no issues at my last check-up. I'm trying to explain that I'm a person who wishes to live a very quiet life. I take care not to trouble myself with any enemies, like winning and losing, that would cause me to lose sleep at night. That is how I deal with society, and I know that is what brings me happiness. Although, if I were to fight I wouldn't lose to anyone.",
        "stats": {
            "ther": 50,
            "belf": 50,
            "polc": 0,
            "cord": 100
        }
    },
];
